﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ellenorzés
{
    internal class ellenorzes
    {
        public static int Buntetes(decimal kmPerOra)
        {
            if (kmPerOra <= 104)
            {
                return 0;
            }
            else if(kmPerOra <= 121)
            {
                return 30000;
            }
            else if(kmPerOra <= 136)
            {
                return 45000;
            }
            else if(kmPerOra <= 151)
            {
                return 60000;
            }
            else
            {
                return 200000;
            }
        }
        static void Main(string[] args)
        {
            List<Record> records = new List<Record>();
            StreamReader reader = new StreamReader("meresek.txt");
            while (!reader.EndOfStream)
            {
                Record egyRecord = new Record(reader.ReadLine());
                records.Add(egyRecord);

            }
            reader.Close();
            Console.WriteLine("2. feladat");
            Console.WriteLine($"A mérés során {records.Count} jármű adatait rögzítették.");
            Console.WriteLine("3. feladat");
            int db = 0;
            foreach (Record egyRecord in records)
            {
                if (egyRecord.kOra < 9)
                {
                    db++;
                }
            }
            Console.WriteLine($"9 óra előtt {db} jármű haladt el a végponti mérőnél.");
            Console.WriteLine("4. feladat");
            Console.Write("Adjon meg egy óra és perc értéket! ");
            string adatBe = Console.ReadLine();
            string[] oraAdatok = adatBe.Split(' ');
            int beOra = int.Parse(oraAdatok[0]);
            int bePerc = int.Parse(oraAdatok[1]);
            db = 0;
            foreach (Record egyRecord in records)
            {
                if (egyRecord.bOra == beOra && egyRecord.bPerc == bePerc)
                {
                    db++;
                }
            }
            Console.WriteLine($"\ta. A kezdeti méréspontnál elhaladt járművek száma: {db}");
            //Balázs
            int k = 0;

            foreach (var item in records)
            {
                int bp = item.bOra * 60 + item.bPerc;
                int kp = item.kOra * 60 + item.kPerc;
                int beIdo = beOra * 60 + bePerc;
                if (bp <= beIdo && beIdo <= kp)
                {
                    k++;
                }
            }
            Console.WriteLine($"b. A forgalomsűrűség: {(double)k / 10}");
            int legGyorsabbIndexe = 0;
            int beIdoEmp = (records[0].bOra * 3600 + records[0].bPerc * 60 + records[0].bMp) * 1000 + records[0].bEmp;
            int kiIdoEmp = (records[0].kOra * 3600 + records[0].kPerc * 60 + records[0].kMp) * 1000 + records[0].kEmp;
            int min = kiIdoEmp - beIdoEmp;
            int i;
            for (i = 1; i < records.Count; i++)
            {
                beIdoEmp = (records[i].bOra * 3600 + records[i].bPerc * 60 + records[i].bMp) * 1000 + records[i].bEmp;
                kiIdoEmp = (records[i].kOra * 3600 + records[i].kPerc * 60 + records[i].kMp) * 1000 + records[i].kEmp;
                int elteltIdoEmp = kiIdoEmp - beIdoEmp;
                //Console.WriteLine("{0} {1}",records[i].rendszam, ((double)10000 / elteltIdoEmp) * 3600);
                if (elteltIdoEmp < min)
                {
                    min = elteltIdoEmp;
                    legGyorsabbIndexe = i;
                }
            }
            Console.WriteLine("5. feladat");
            Console.WriteLine("A legnagyobb sebességgel haladó jármű");
            Console.WriteLine($"\trendszáma: {records[legGyorsabbIndexe].rendszam}");
            Console.WriteLine($"\tátlagsebessége: {Math.Floor((double)10000 / min * 3600)} km / h");
            //5. feladat
            bool kilep = false;
            int j = legGyorsabbIndexe; //hogy ne írjunk sokat
            i = 0;  //ciklusszámláló a do-while ciklusban
            db = 0; //lehagyott autók száma
            //leggyorsabb autós be és kilépési ideje emp-ben
            int lbeIdoEmp = (records[j].bOra * 3600 + records[j].bPerc * 60 + records[j].bMp) * 1000 + records[j].bEmp;
            int lkiIdoEmp = (records[j].kOra * 3600 + records[j].kPerc * 60 + records[j].kMp) * 1000 + records[j].kEmp;
            do
            {
                //aktuális autós be- és kilépési ideje emb-be
                beIdoEmp = (records[i].bOra * 3600 + records[i].bPerc * 60 + records[i].bMp) * 1000 + records[i].bEmp;
                kiIdoEmp = (records[i].kOra * 3600 + records[i].kPerc * 60 + records[i].kMp) * 1000 + records[i].kEmp;
                if (beIdoEmp < lbeIdoEmp && kiIdoEmp>lkiIdoEmp)
                {
                    db++;
                }
                if (beIdoEmp>lbeIdoEmp)
                {
                    kilep = true;
                }
                i++;
            } while (!kilep);
            Console.WriteLine($"által lehagyott járművek száma: {db}");
            Console.WriteLine("6. feladat");
            int gyorshajtokSzama = 0;
            for ( i = 0; i < records.Count; i++)
            {
                beIdoEmp = (records[i].bOra * 3600 + records[i].bPerc * 60 + records[i].bMp) * 1000 + records[i].bEmp;
                kiIdoEmp = (records[i].kOra * 3600 + records[i].kPerc * 60 + records[i].kMp) * 1000 + records[i].kEmp;
                int elteltIdoEmp = kiIdoEmp - beIdoEmp;
                if ((double)10000 / elteltIdoEmp * 3600 > 90)
                {
                    gyorshajtokSzama++;
                }
            }
            Console.WriteLine($"A járművek {Math.Round((double)gyorshajtokSzama/records.Count*100,2)} % -a volt gyorshajtó.");
            //7. feladat
            StreamWriter writer = new StreamWriter("buntetes.txt");
            for (i = 0; i < records.Count; i++)
            {
                beIdoEmp = (records[i].bOra * 3600 + records[i].bPerc * 60 + records[i].bMp) * 1000 + records[i].bEmp;
                kiIdoEmp = (records[i].kOra * 3600 + records[i].kPerc * 60 + records[i].kMp) * 1000 + records[i].kEmp;
                int elteltIdoEmp = kiIdoEmp - beIdoEmp;
                decimal kmPerOra = Math.Floor((decimal)10000 / elteltIdoEmp * 3600);
                if (Buntetes(kmPerOra)>0)
                {
                writer.WriteLine($"{records[i].rendszam}\t{kmPerOra} km/h\t{Buntetes(kmPerOra)} Ft");
                }
            }
            writer.Close();
            Console.WriteLine();
            Console.WriteLine("A fájl elkészült.");
            Console.ReadKey();
        }
    }
}

