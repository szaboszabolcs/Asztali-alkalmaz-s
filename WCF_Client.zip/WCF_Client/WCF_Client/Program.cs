﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using WCF_Client.ServiceReference1;

namespace WCF_Client
{
    internal class Program
    {
        public static ServiceReference1.Service1Client kliens;

        public static Kutya EgyKutyaGet()
        {
            Kutya Kutya = new Kutya();
            WebClient client = new WebClient();
            JObject jObject = new JObject();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = System.Text.Encoding.UTF8;
            string result = client.DownloadString("http://localhost:3000/" + "EgyKutyaAdatai");
            
            Kutya = JsonConvert.DeserializeObject<Kutya>(result);
            return Kutya;
        }

        class KutyaAdat
        {
            public string ClassName = "kutya";
            public Kutya kutya { get; set; }
        }
        public static string EgyKutyaAdd(Kutya kutya)
        {
            KutyaAdat egyAdat = new KutyaAdat();
            egyAdat.kutya = kutya;
            //Console.WriteLine(egyAdat.ClassName);
            //Console.WriteLine(egyAdat.kutya);
            WebClient client = new WebClient();
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            client.Encoding = System.Text.Encoding.UTF8;
            string result = client.UploadString("http://localhost:3000/EgyKutyaAdd","POST", JsonConvert.SerializeObject(egyAdat));
            return result;
        }
        static void Main(string[] args)
        {
            kliens = new ServiceReference1.Service1Client();

            Kutya kutya = new Kutya();
            kutya.ID = 17;
            kutya.Nev = "Yato";
            kutya.Gazdi = "Mind1";
            kutya.Eletkor = 42;
            kutya.Fajta = "Orosz agár";
            kutya.Neme = true;
            kutya.LabakSzama = 5;
            Console.WriteLine(kliens.EgyKutyaAddCS(kutya));
            kutya.ID = 123;
            kutya.Gazdi = "Bence";
            Console.WriteLine(EgyKutyaAdd(kutya));
            kutya.ID = 9;
            kutya.Gazdi = "ÁDÁM";
            Console.WriteLine(kliens.EgyKutyaPutCS(kutya));

            Kutya ek = kliens.EgyKutyaGetCS();
            Console.WriteLine(ek.Gazdi);
            Kutya egyKutya = EgyKutyaGet();
            Console.WriteLine(egyKutya.Gazdi);
            for (int i = 0; i < 0; i++)
            {
                kliens.EgyKutyaPostCS();
            }
            Console.ReadKey();
            kliens.Close();
        }
    }
}
